import React, { FC, useEffect, useState } from 'react';
import { Layout, Row, Col } from 'antd';
import Navbar from './NavBar'
import './Header.css';


const Header: FC = () => {
  const { Header } = Layout;
  const history = useHistory()
  const location = useLocation()
  const { userSession } = useSelector((state: any) => state.userData)
  const [path, setPath] = useState('')
  const { selectedTenantName, selectedDeviceType } = useSelector((state: any) => state.deviceData)
  const { dashboardPath, deviceManagementPath } = URLPaths;
  

  useEffect(() => {
   
  }, [])

  return (
    <Header className="header" id='harder'>
      <Row id='header-content'>
        <Col  id='header-title'>
          <div className='header-title'>
            <NavLink to={dashboardPath} >
              <p className="heading" id='#title'> Project<sup className='superscript-tm'>TM</sup>Operations</p>
            </NavLink>
            
          </div>
        </Col>
      </Row>
    </Header>
  );
};
export default Header;